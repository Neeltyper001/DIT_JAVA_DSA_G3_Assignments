package com.brainmentors.bookingsystem.movies.views;

import java.util.Scanner;

import com.brainmentors.bookingsystem.movies.dto.MoviesDTO;
import com.brainmentors.bookingsystem.movies.services.MovieService;

public class MovieView {
	MovieService movieService;
	public void showMovie() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Movie Name");
		String movieName = scanner.next();
		
		if(!(movieService instanceof MovieService)) {
			System.out.println("MovieView");
			movieService = new MovieService();
		}
		
		MoviesDTO moviesDTO = movieService.getMovieByName(movieName);
		
		if(moviesDTO == null) {
			System.out.println("No movie exists...");
		}
		
		else {
			System.out.println("Movie "+moviesDTO);
			System.out.println("Enter the Seat to Booked B/w 1 to 5");
			try {
				int seatNo = scanner.nextInt();
				moviesDTO.getShow().getAudiDTO().bookTicket(seatNo);
				System.out.println("After Booked "+moviesDTO);				
			}
			
			catch(Exception e) {
				System.out.println("Please enter the valid seat Number");
			}
		}
		//scanner.close();
	}
}
