package com.brainmentors.bookingsystem.movies.services;

import com.brainmentors.bookingsystem.movies.dto.MoviesDTO;
import com.brainmentors.bookingsystem.movies.repository.MovieRepository;

public class MovieService {
	MovieRepository movieRepo;
	public MoviesDTO getMovieByName(String movieName) {
		if(!(movieRepo instanceof MovieRepository)) {			
			movieRepo = new MovieRepository();
		}
		for(MoviesDTO movieObject : movieRepo.getAllMovies()) {
			if(movieObject != null) {
				if(movieObject.getName().equalsIgnoreCase(movieName)) {
					return movieObject;
				}
			}
		}
		return null;
	}
}
