package com.brainmentors.bookingsystem.movies.dto;

public class ShowDTO {
	private String timing;
	private AudiDTO audiDTO;
	public String getTiming() {
		return timing;
	}
	public void setTiming(String timing) {
		this.timing = timing;
	}
	public AudiDTO getAudiDTO() {
		return audiDTO;
	}
	public void setAudiDTO(AudiDTO audiDTO) {
		this.audiDTO = audiDTO;
	}
	
	@Override
	public String toString() {
		return " timing= "+timing+ ", "+audiDTO;
	}
}
