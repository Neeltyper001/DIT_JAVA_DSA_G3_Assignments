package com.brainmentors.bookingsystem.movies.dto;

public class AudiDTO {
	private int capacity;
	private TicketDTO [] tickets;
	public AudiDTO() {
		capacity = 5;
		tickets =  new TicketDTO[capacity];
		for(int i=0; i<tickets.length; i++) {
			tickets[i] = new TicketDTO();
		}
	}
	
	public void bookTicket(int seatNo) {
		if(seatNo < 1 || seatNo > tickets.length ) {
			System.out.println("Invalid Seat No");
			return;
		}
		if(isHallFull()) {
			System.out.println("Hall full....");
			return;
		}
		for(int i=0; i<tickets.length; i++) {
			TicketDTO obj = tickets[i];
			if(obj.getSeatNumber() != null && obj.getSeatNumber().equals(""+seatNo)) {
				System.out.println("Seat Already booked ");
				return;
			}
			
			if(obj.getSeatNumber() == null ) {
				obj.setSeatNumber(""+seatNo);
				System.out.println("Seat Booked ....");
				return;
			}
		}
	}
	
	public boolean isHallFull() {
		for(int i=0; i<tickets.length; i++) {
			TicketDTO obj = tickets[i];
			if(obj.getSeatNumber() == null) {
				return false;
			}
		}
		return true;
	}
	
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public TicketDTO[] getTickets() {
		return tickets;
	}
	public void setTickets(TicketDTO[] tickets) {
		this.tickets = tickets;
	}
	
	@Override
	public String toString() {
		String audiRecord = "";
		
		for(int i=0; i<tickets.length; i++) {
			audiRecord+= tickets[i];
		}
		return "capacity= "+capacity+", tickets = ["+audiRecord;
	}
}
