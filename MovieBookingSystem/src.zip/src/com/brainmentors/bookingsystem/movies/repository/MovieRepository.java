package com.brainmentors.bookingsystem.movies.repository;

import com.brainmentors.bookingsystem.movies.dto.MoviesDTO;
public class MovieRepository {
	private ShowRepository showRepo;
	private MoviesDTO movie;
	private MoviesDTO [] movies;
	public MoviesDTO[] getAllMovies() {
		if(!(showRepo instanceof ShowRepository)) {			
			showRepo = new ShowRepository();
		}
		if(!(movie instanceof MoviesDTO)) {			
			 movie = new MoviesDTO();
			 movies = new MoviesDTO[2];
		}
		movie.setName("Pushpa");
		movie.setPrice(200);
		movie.setDesc("In Hindi");
		movie.setRating(8.5);
		showRepo.addShow(movie);
		movies[0] = movie;
//		movies[1] = new MoviesDTO("KGF",100,"In Hindi",8.6);
		return movies;
	}
}
