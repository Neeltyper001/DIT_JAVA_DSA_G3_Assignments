package com.brainmentors.bookingsystem.movies.repository;

import com.brainmentors.bookingsystem.movies.dto.AudiDTO;
import com.brainmentors.bookingsystem.movies.dto.MoviesDTO;
import com.brainmentors.bookingsystem.movies.dto.ShowDTO;

public class AudiRepository {
	private TicketRepository ticketRepo;
	private AudiDTO audiDTO;
	public AudiDTO addAudi(ShowDTO showDTO) {
		if(!(audiDTO instanceof AudiDTO)) {
			audiDTO = new AudiDTO();
		}
		if(!(ticketRepo instanceof TicketRepository)) {			
			ticketRepo = new TicketRepository();
		}
		audiDTO.setCapacity(5);
		audiDTO.setTickets(ticketRepo.addTickets(audiDTO));
		return audiDTO;
	}
}
