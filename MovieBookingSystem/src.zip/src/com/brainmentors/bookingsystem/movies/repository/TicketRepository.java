package com.brainmentors.bookingsystem.movies.repository;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

import com.brainmentors.bookingsystem.movies.dto.AudiDTO;

import com.brainmentors.bookingsystem.movies.dto.TicketDTO;
import com.brainmentors.bookingsystem.movies.dto.ShowDTO;
public class TicketRepository {
//	TicketRepository ticketRepo;
	public TicketDTO[] addTickets(AudiDTO audiDTO) {
		TicketDTO tickets[] =  audiDTO.getTickets();
		return tickets;
	}
}
