package com.brainmentors.bookingsystem.movies.repository;

import com.brainmentors.bookingsystem.movies.dto.MoviesDTO;
import com.brainmentors.bookingsystem.movies.dto.ShowDTO;

public class ShowRepository {
	private AudiRepository audi;
	private ShowDTO showDTO;
	public ShowDTO addShow(MoviesDTO movie) {
		if(!(showDTO instanceof ShowDTO)) {			
			showDTO = new ShowDTO();
		}
		if(!(audi instanceof AudiRepository)) {
			audi = new AudiRepository();
		}

		showDTO.setTiming("6:00 P.M.");
		showDTO.setAudiDTO(audi.addAudi(showDTO));
		movie.setShow(showDTO);
		return showDTO;
	}
	
	public boolean removeShow(MoviesDTO movie) {
		return false;
	}
	
}
